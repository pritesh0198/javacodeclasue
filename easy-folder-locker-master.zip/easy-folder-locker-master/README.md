# Easy Folder Locker v1.0

- How to run Easy Folder Locker jar
```
mvn clean install
java -jar target/easy-folder-locker-1.0.jar
```
