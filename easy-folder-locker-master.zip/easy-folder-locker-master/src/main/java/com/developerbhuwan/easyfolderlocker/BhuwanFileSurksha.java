package com.developerbhuwan.easyfolderlocker;

import com.developerbhuwan.easyfolderlocker.ui.MainUI;

/**
 *
 * @author Bhuwan Upadhyay
 */
public class BhuwanFileSurksha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new MainUI().setApp();       
    }
    
}
