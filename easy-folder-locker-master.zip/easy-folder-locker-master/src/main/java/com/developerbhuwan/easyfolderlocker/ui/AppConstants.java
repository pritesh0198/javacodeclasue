/*
 * Copyright (C) 2014 DeveloperBhuwan
 * Developer: Bhuwan Pd. Upadhyay
 */
package com.developerbhuwan.easyfolderlocker.ui;

/**
 *
 * @author DeveloperBhuwan
 */
public class AppConstants {
    public static final String APP_DIR = "/Easy Folder Locker/";
    public static final String APP_LOG_PATH = "/Easy Folder Locker/log/";
}
