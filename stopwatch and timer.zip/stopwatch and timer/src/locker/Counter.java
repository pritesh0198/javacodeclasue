package locker;

import javax.swing.*;
import javax.swing.text.NumberFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.time.LocalTime;

public class Counter extends JFrame implements ActionListener {
    private final JButton startButton;
    private final JButton stopButton;
    private final JButton resetButton;
    private final JFormattedTextField hoursField;
    private final JFormattedTextField minutesField;
    private final JFormattedTextField secondsField;
    private final JLabel displayLabel;
    private Timer timer;
    private LocalTime time = LocalTime.of(0, 0, 0);

    public Counter() {
        super("Reverse Countdown Timer");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        // Create the input fields for hours, minutes, and seconds
        NumberFormat format = NumberFormat.getInstance();
        NumberFormatter formatter = new NumberFormatter(format);
        formatter.setValueClass(Integer.class);
        formatter.setMinimum(0);
        formatter.setMaximum(Integer.MAX_VALUE);
        formatter.setAllowsInvalid(false);
        formatter.setCommitsOnValidEdit(true);

        hoursField = new JFormattedTextField(formatter);
        minutesField = new JFormattedTextField(formatter);
        secondsField = new JFormattedTextField(formatter);

        // Create a panel to hold the input fields
        JPanel inputPanel = new JPanel(new GridLayout(2, 3));
        inputPanel.add(new JLabel("Hours:"));
        JLabel label_1 = new JLabel("Minutes:");
        inputPanel.add(label_1);
        JLabel label = new JLabel("Seconds:");
        inputPanel.add(label);
        inputPanel.add(hoursField);
        inputPanel.add(minutesField);
        inputPanel.add(secondsField);

        // Add the input panel to the window
        getContentPane().add(inputPanel, BorderLayout.CENTER);

        // Create a label to display the remaining time
        displayLabel = new JLabel("00:00:00");
        getContentPane().add(displayLabel, BorderLayout.NORTH);

        // Create a panel to hold the start, stop, and reset buttons
        JPanel buttonPanel = new JPanel();
        
        startButton = new JButton("Start");
        startButton.addActionListener(this);
        buttonPanel.add(startButton);
        
        stopButton = new JButton("Stop");
        stopButton.addActionListener(this);
        buttonPanel.add(stopButton);
        
        resetButton = new JButton("Reset");
        resetButton.addActionListener(this);
        buttonPanel.add(resetButton);

        // Add the button panel to the window
        getContentPane().add(buttonPanel, BorderLayout.PAGE_END);

        // Create a timer to update the countdown display
        timer = new Timer(1000, e -> {
            time = time.minusSeconds(1);
            if (time.equals(LocalTime.MIN)) {
                Toolkit.getDefaultToolkit().beep();
                JOptionPane.showMessageDialog(null, "Countdown ended!", "Ended", JOptionPane.INFORMATION_MESSAGE);
                timer.stop(); 
            }
            secondsField.setText(String.valueOf(time.getSecond()));
            minutesField.setText(String.valueOf(time.getMinute()));
            hoursField.setText(String.valueOf(time.getHour()));
            String timeString = String.format("%02d:%02d:%02d", time.getHour(), time.getMinute(), time.getSecond());
            displayLabel.setText(timeString);
            
            pack();
            repaint();
            
            if (time.equals(LocalTime.MIN)) {
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                resetButton.setEnabled(true);
            }
            
            if (timer.isRunning()) {
                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                resetButton.setEnabled(false);                
            }
            
            if (!timer.isRunning()) {
                startButton.setEnabled(true);
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            pack();
            repaint();
            
            if (time.equals(LocalTime.MIN)) {
                startButton.setEnabled(true);
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            if (timer.isRunning()) {
                startButton.setEnabled(false);                
                stopButton.setEnabled(true);                
                resetButton.setEnabled(false);                
            }
            
            if (!timer.isRunning()) {
                startButton.setEnabled(true);                
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            pack();
            repaint();
            
            if (time.equals(LocalTime.MIN)) {
                startButton.setEnabled(true);                
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            if (timer.isRunning()) {
                startButton.setEnabled(false);                
                stopButton.setEnabled(true);                
                resetButton.setEnabled(false);                
            }
            
            if (!timer.isRunning()) {
                startButton.setEnabled(true);                
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            pack();
            repaint();
            
            if (time.equals(LocalTime.MIN)) {
                startButton.setEnabled(true);                
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            if (timer.isRunning()) {
                startButton.setEnabled(false);                
                stopButton.setEnabled(true);                
                resetButton.setEnabled(false);                
            }
            
            if (!timer.isRunning()) {
                startButton.setEnabled(true);                
                stopButton.setEnabled(false);                
                resetButton.setEnabled(true);                
            }
            
            pack();
            repaint();
        });

        pack();
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    	if (e.getSource() == startButton) {
            time = LocalTime.of(Integer.parseInt(hoursField.getText()), Integer.parseInt(minutesField.getText()), Integer.parseInt(secondsField.getText()));
            timer.start();
    	} else if (e.getSource() == stopButton) {
    		timer.stop();
    	} else if (e.getSource() == resetButton) {
    		hoursField.setText("0");
    		minutesField.setText("0");
    		secondsField.setText("0");
    		time = LocalTime.of(0, 0, 0);
    		timer.stop();
    	}
    }

    public static void main(String[] args) {
    	SwingUtilities.invokeLater(Counter::new);
    }
}
