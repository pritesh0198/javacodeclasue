package locker;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Stopwatch extends JFrame implements ActionListener {
    private Timer timer;
    private long startTime = -1;
    private long elapsedTime = 0;
    private final JLabel timeLabel = new JLabel("00:00:00.000");
    private final JButton startButton = new JButton("Start");
    private final JButton stopButton = new JButton("Stop");
    private final JButton resetButton = new JButton("Reset");
    private final JButton nextButton = new JButton("Timer");

    public Stopwatch() {
        super("Stopwatch");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setResizable(false);

        JPanel panel = new JPanel();
        panel.add(timeLabel);
        panel.add(startButton);
        panel.add(stopButton);
        panel.add(resetButton);
        panel.add(nextButton);
        add(panel);

        startButton.addActionListener(this);
        stopButton.addActionListener(this);
        resetButton.addActionListener(this);
        nextButton.addActionListener(this);
        
        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (startTime < 0) {
                    startTime = System.currentTimeMillis();
                }
                elapsedTime = System.currentTimeMillis() - startTime;
                int milliseconds = (int) (elapsedTime % 1000);
                int seconds = (int) ((elapsedTime / 1000) % 60);
                int minutes = (int) ((elapsedTime / (1000 * 60)) % 60);
                int hours = (int) ((elapsedTime / (1000 * 60 * 60)) % 24);
                String time = String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, milliseconds);
                timeLabel.setText(time);
            }
        });

        pack();
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            timer.start();
        } else if (e.getSource() == stopButton) {
            timer.stop();
            startTime = -1;
            elapsedTime = 0;
            timeLabel.setText("00:00:00.000");
        } else if (e.getSource() == resetButton) {
            startTime = -1;
            elapsedTime = 0;
            timeLabel.setText("00:00:00.000");
        }
        else if (e.getSource() == nextButton) {
        	 JFrame Counter = new JFrame("Timer");
        	 Counter.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	 Counter.setSize(300, 100);
        	 Counter.setVisible(true);
        	 

        }
    }

    public static void main(String[] args) {
        new Stopwatch();
        
        
    }
}
